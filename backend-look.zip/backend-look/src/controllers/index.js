import osFile from '../utils/file-system.js'
const createUser = (req, res) => {
    const { username, phone } = req.body
    let users = osFile.read('users')
    const newUser = {
        id: users.length ? users.at(-1).id + 1 : 1,
        username,
        phone
    }
    users.push(newUser)
    osFile.write('users', users)
    res.status(201).json({
        status: 201,
        message: 'User successfully created!'
    })
}

const addFood = (req, res) => {
    const { userId } = req.params
    const { food_name,count } = req.body
    let foods = osFile.read('foods')
    const food = foods.find(food => food.food_name == food_name)
    if (!food) {
       return res.status(404).json({
        status: 404,
        message: 'Do not have this type of food!'
       }) 
    }
    if(+count > 10 || +count < 1) {
        return res.status(404).json({
        status: 404,
        message: 'Enter right count!'
       }) 
    }
    
    let orders = osFile.read('orders')
    const newOrder = {
        id: orders.length ? orders.at(-1).id + 1 : 1,
        food_id: food.food_id,
        userId,
        count
    }
    orders.push(newOrder)
    osFile.write('orders', orders)
    res.status(200).json({
        status: 200,
        message: "Order added!",
        data: newOrder
    })
}

const allUsers = (req, res) => {
    let users = osFile.read('users')
    res.status(200).json({
        status: 200,
        data: users
    })
}

const getOrder = (req, res) => {
    const { userId } = req.params

    let orders = osFile.read('orders')
    orders = orders.filter(order => order.userId == userId)
    res.status(200).json({
        status: 200,
        data: orders
     }) 
    console.log(orders)
}

const getUser = (req, res) => {
    const { userId } = req.params
    let users = osFile.read('users')
    const user = users.find(user => user.id == userId)
    res.status(200).json({
        status: 200,
        data: user
    })
}

const updateOrder = (req, res) => {
    const { orderId, count } = req.body
    let orders = osFile.read('orders')
    const order = orders.find(order => order.id == orderId)
    if (!order) {
        return res.status(404).json({
            status: 404,
            message: 'Order undefined'
        })
    }  
    if(+count > 10 || +count < 1) {
        return res.status(404).json({
        status: 404,
        message: 'Enter right count!'
       }) 
    }
    order.count = +order.count + +count
    order.count = String(order.count)
    osFile.write('orders', orders)
    res.status(200).json({
        status: 200,
        data: order
    })
}

export default {
    createUser,
    addFood,
    allUsers,
    getOrder,
    getUser,
    updateOrder
}