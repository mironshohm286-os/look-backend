import express from 'express'
import registerController from '../controllers/index.js'
import middleware from '../middleware/validation.js'
import { checkId } from '../utils/guard.js'
const  router = express.Router()

router
    .post('/api/register', middleware.checkNewUser, registerController.createUser)
    .post('/api/foods/:userId',checkId, registerController.addFood)
    .get('/api/users', registerController.allUsers)
    .get('/api/orders/:userId', checkId, registerController.getOrder)
    .get('/api/user/:userId', checkId, registerController.getUser)
    .put('/api/orders', registerController.updateOrder)
export default router