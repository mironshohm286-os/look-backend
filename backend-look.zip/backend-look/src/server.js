import express from 'express'
import { configDotenv } from 'dotenv'
import Router from './routers/index.js'
configDotenv()

const app = express()
app.use(express.json())
app.use(Router)
app.use('/uploads', express.static('uploads'))

app.listen(process.env.PORT, () => console.log('Server is running...'))