import { userScheme } from "../utils/validation.js"

export default {
    checkNewUser: (req, res, next) => {
        const { error } = userScheme.validate(req.body)

        if (error) {
            return res.status(404).json({
                status: 404,
                message: error.message
            })
        }

        next()
    }
}