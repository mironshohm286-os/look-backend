import path from 'path'
import fs from 'fs'

export default {
    read: (filename) => {
        let data = fs.readFileSync(path.join(process.cwd(), 'src', 'db', `${filename}.json`), 'utf-8')
        data = JSON.parse(data)
        return data
    },

    write: (filename, data) => {
        fs.writeFileSync(path.join(process.cwd(), 'src', 'db', `${filename}.json`), JSON.stringify(data, null, 4))
    }
}
