import Joi from 'joi'
export let userScheme = Joi.object({
    username: Joi.string().required().min(3),
    phone: Joi.string().pattern(/^998\d{9}$/)
})
