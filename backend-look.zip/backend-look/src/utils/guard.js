import osFile from './file-system.js'
export let checkId = (req, res, next) => {
    const { userId } = req.params
    let users = osFile.read('users')
    const user = users.find(user => user.id == userId)
    if(!user) {
        res.status(404).json({
            status: 404,
            message: 'Undefined User!'
        })
    }
    next()
}